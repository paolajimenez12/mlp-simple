# Informe del experimento MLP

## Arquitectura
(pegue aquí el `model.summary()`)

## Métricas finales
- Test loss: <valor>
- Test accuracy: <valor>

## Hashes (ledger)
- notebook: <sha256>
- model: <sha256>
- report: <sha256>

## Fecha
2025-11-06T14:01:12.668731 UTC
